#!/bin/bash

date

current_time=$(date +%s)
echo "Current_time: $current_time"
let date=date*2
echo "Current_time: $current_time"

for i in {1..20}; do
	echo "Number: $i"
done
